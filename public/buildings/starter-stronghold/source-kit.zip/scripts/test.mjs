import {createServer} from 'vite';
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
const vite=await createServer({configFile:false,server:{middlewareMode:true},logLevel:'error'});
try{
 const {PALISADE,palisadeColumns,starterEnclosure}=await vite.ssrLoadModule('/src/stronghold/starter-enclosure.ts');
 const prefab=JSON.parse(await fs.readFile('src/stronghold/prefabs/stronghold.json','utf8'));
 const props=starterEnclosure(prefab.props.map(p=>({...p,x:577+(p.u-p.v)*64,y:-160+(p.u+p.v)*32}))),walls=props.filter(p=>p.id.startsWith('rampart-'));
 assert.equal(walls.length,12);assert.equal(props.filter(p=>p.id==='bastion').length,0);
 for(const p of walls){
  const slope=p.id==='rampart-ne'?-.5:.5;
  // Source end-post centers must hit the ground segment endpoints after the
  // actual renderer width, foot, shear and vertical transformation.
  const feet=p.id==='rampart-ne'?[[46,361],[342,215]]:[[46,215],[342,361]];
  for(const [x,y]of feet){const dx=(x/388-.5)*p.width,dy=dx*p.shear+p.vertical*(y/370-p.foot)*370*p.width/388;assert(Math.abs(dy-dx*slope)<1e-8);assert(Math.abs(Math.abs(dx)-160)<1e-8);}
  const cols=palisadeColumns(p);assert.equal(cols.length,81);assert(cols.every(c=>Number.isFinite(c.back)&&c.front>c.back&&c.height===PALISADE.height));
 }
 const ASSETS=JSON.parse(await fs.readFile('src/environment/catalog.json','utf8')).assets;
 const preview=ASSETS.find(a=>a.id==='stronghold').components;
 assert.equal(preview.filter(p=>p.file.includes('/starter-stronghold/palisade-')).length,12);
 assert(!preview.some(p=>p.file.endsWith('/bastion.png')));
 for(const name of ['palisade-ne.png','palisade-se.png','watchtower-01.png','runetower-01.png'])assert((await fs.stat('public/buildings/starter-stronghold/'+name)).size>1000);
 await fs.mkdir('docs/starter-stronghold',{recursive:true});await fs.writeFile('docs/starter-stronghold/geometry.json',JSON.stringify({pass:true,walls:12,sourceEndpointTransform:true,continuousWallColumns:81,editorMatches:true,removedStoneBastions:true,gateAndCoreUnchanged:true},null,2)+'\n');
 console.log('PASS: real prefab transformations, calibrated end-post contacts, continuous wall collision and matching editor components');
}finally{await vite.close();}
