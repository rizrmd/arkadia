import {Application,Assets,Container,Graphics,Sprite,Text} from './pixi.min.mjs';
const assetBase=new URL('./',import.meta.url);
const manifest=await (await fetch(new URL('manifest.json',assetBase))).json();
const app=new Application();await app.init({resizeTo:window,background:'#dce5e7',antialias:true});document.body.appendChild(app.canvas);
const root=new Container();app.stage.addChild(root);let level=Number(new URLSearchParams(location.search).get('level'))||1;
const text=(str,x,y,size=18)=>{const t=new Text({text:str,style:{fontFamily:'Arial',fontSize:size,fill:'#253740',wordWrap:true,wordWrapWidth:app.screen.width-44}});t.position.set(x,y);root.addChild(t);return t;};
const textures={};for(const p of [...manifest.milestones.map(m=>m.file),'repair-strap.png'])textures[p]=await Assets.load(new URL(p,assetBase).href);
function draw(){root.removeChildren();const w=app.screen.width,h=app.screen.height,row=manifest.levels[level-1];
 text('MINE / PAINTED ASSET REVIEW',22,20,Math.min(25,w/22));text(`Level ${level} / 30 · Milestone ${row.milestone}`,22,58);
 const size=Math.min(w-30,h-210,800),x=(w-size)/2,y=95;
 const garden=new Container();garden.position.set(x,y);garden.scale.set(size/manifest.canvas[0]);root.addChild(garden);
 garden.addChild(new Sprite(textures[row.sprite]));
 for(const p of row.decals){const s=new Sprite(textures['repair-strap.png']);s.anchor.set(.5);s.position.set(p.x,p.y);s.width=p.size;s.height=p.size;garden.addChild(s);}
 text(row.detail,22,h-106,Math.min(17,w/37));
 function button(label,x,cb){const b=new Container();b.position.set(x,h-65);b.addChild(new Graphics().roundRect(0,0,112,42,7).fill('#294453'));const t=new Text({text:label,style:{fontFamily:'Arial',fontSize:16,fill:'#ffffff'}});t.anchor.set(.5);t.position.set(56,21);b.addChild(t);b.eventMode='static';b.cursor='pointer';b.on('pointertap',cb);root.addChild(b);}
 button('Previous',20,()=>{level=Math.max(1,level-1);draw();});button('Next',142,()=>{level=Math.min(30,level+1);draw();});
 text('Visual assets only · No production or upgrade gameplay',22,h-18,Math.min(12,w/42));
 window.__mineReview={ready:true,level,milestone:row.milestone,decals:row.decals.length,canvas:manifest.canvas};
}
app.renderer.on('resize',draw);draw();
